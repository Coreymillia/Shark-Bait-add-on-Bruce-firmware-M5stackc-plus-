# SD FILES

Here are some examples for you to put on your SD card with functionalities that Bruce supports
