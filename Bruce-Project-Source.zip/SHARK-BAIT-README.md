# 🦈 Shark-Bait WiFi Security Suite

## Overview
Shark-Bait is a comprehensive WiFi security detection and response system for ESP32 devices. It provides real-time monitoring and active countermeasures against common WiFi attacks.

## 🎯 Features

### 1. **Threat Monitor** 
Real-time WiFi packet analysis detecting:
- **Beacon Spam** (>2 beacons/second)
- **Deauth Floods** (>1 deauth/second) 
- **Probe Floods** (>5 probes/second)
- **Evil Twin APs** (multi-SSID broadcasting)
- **Rapid Activity Spikes**
- **Burst Pattern Analysis**

### 2. **Honeypot Trap**
Strategic honeypot SSID deployment to catch:
- Karma attackers
- Automatic connection attempts
- Malicious response probing

### 3. **Counter Attack** 
Educational disruption system broadcasting:
- Security awareness beacons
- Attack warning SSIDs
- Protective spectrum flooding

### 4. **Card Skimmer Hunt**
Detection of payment fraud networks:
- ATM-related SSIDs
- Banking impersonation APs
- POS system backdoors

### 5. **Test Beacon Spam**
Built-in verification tool for testing detection capabilities

## 🚀 Quick Start

1. Flash `Shark-Bait-v1.0-WORKING.bin` to your ESP32 device
2. Navigate to **Shark-Bait** in the main menu
3. Select **Threat Monitor** to start detection
4. Monitor serial console for detailed analysis
5. Use **Test Beacon Spam** on another device to verify detection

## 🔧 Technical Details

### Detection Algorithm
- **3-second sliding window** analysis
- **0.5-second** analysis frequency
- **Multi-layered risk scoring** system
- **SSID extraction** from beacon frames
- **Real-time packet callback** processing

### Thresholds (Tuned for Real-World Use)
```cpp
BEACON_SPAM_THRESHOLD = 2     // beacons/second
DEAUTH_ATTACK_THRESHOLD = 1   // deauths/second  
PROBE_FLOOD_THRESHOLD = 5     // probes/second
ATTACK_DETECTION_THRESHOLD = 2 // risk score
```

## 🎮 Usage

### Threat Monitor
1. Activates promiscuous WiFi monitoring
2. Analyzes all management frames
3. Displays threat status on screen
4. Outputs detailed analysis to serial console
5. Press any key to stop monitoring

### Counter Attack
1. Only works when threats are detected
2. Broadcasts educational warning beacons
3. Disrupts malicious AP operations
4. Warns potential victims

## 🛡️ Educational Purpose

This tool is designed for:
- **Network security education**
- **Wireless penetration testing**
- **Security awareness training**
- **Research and development**

**Use responsibly and only on networks you own or have permission to test.**

## 📊 Status Indicators

- 🟢 **SAFE - Waters secured** - No threats detected
- 🔴 **🚨 SHARKS DETECTED 🚨** - Active threats found
- **Devices tracked** - Total unique devices seen
- **Threats found** - Number of malicious devices
- **Active devices** - Currently transmitting devices

## 🐛 Troubleshooting

### If detection seems too sensitive:
- Increase thresholds in code
- Adjust `ATTACK_DETECTION_THRESHOLD`

### If detection misses attacks:
- Decrease thresholds
- Check serial console for analysis data
- Verify promiscuous mode is working

## 🏗️ Building from Source

```bash
git clone <repository>
cd Bruce-1
pio run -t upload
```

## 📈 Version History

### v1.0 - Initial Release ✅
- Working threat detection
- All 4 implementations functional
- Tuned thresholds for real-world use
- Comprehensive WiFi security suite

---

**Made with 🦈 by the Shark-Bait team**