#include <OneWire.h>

void setup_ibutton();
void write_ibutton();
void read_ibutton();
void setiButtonPinMenu();
