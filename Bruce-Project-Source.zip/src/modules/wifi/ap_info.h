#ifndef __AP_INFO_H__
#define __AP_INFO_H__

void displayAPInfo();

#endif
