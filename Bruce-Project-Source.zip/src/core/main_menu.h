#ifndef __MAIN_MENU_H__
#define __MAIN_MENU_H__

#include <MenuItemInterface.h>

#include "menu_items/AntiPredatorMenu.h"
#include "menu_items/BleMenu.h"
#include "menu_items/ConfigMenu.h"
#include "menu_items/FMMenu.h"
#include "menu_items/IRMenu.h"
#include "menu_items/RFMenu.h"
#include "menu_items/WifiMenu.h"

class MainMenu {
public:
    AntiPredatorMenu antiPredatorMenu;
    BleMenu bleMenu;
    ConfigMenu configMenu;
    FMMenu fmMenu;
    IRMenu irMenu;
    RFMenu rfMenu;
    WifiMenu wifiMenu;

    MainMenu();
    ~MainMenu();

    void begin(void);
    std::vector<MenuItemInterface *> getItems(void) { return _menuItems; }
    void hideAppsMenu();

private:
    int _currentIndex = 0;
    int _totalItems = 0;
    std::vector<MenuItemInterface *> _menuItems;
};
extern MainMenu mainMenu;

#endif
