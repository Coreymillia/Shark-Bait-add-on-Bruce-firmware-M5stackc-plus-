#ifndef __SERIAL_SOUND_CMD_H__
#define __SERIAL_SOUND_CMD_H__

#include <SimpleCLI.h>

void createSoundCommands(SimpleCLI *cli);

#endif
