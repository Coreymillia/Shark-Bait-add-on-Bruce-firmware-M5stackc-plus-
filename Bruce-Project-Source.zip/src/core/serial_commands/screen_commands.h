#ifndef __SERIAL_SCREEN_CMD_H__
#define __SERIAL_SCREEN_CMD_H__

#include <SimpleCLI.h>

void createScreenCommands(SimpleCLI *cli);

#endif
