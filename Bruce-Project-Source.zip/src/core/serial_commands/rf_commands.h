#ifndef __SERIAL_RF_CMD_H__
#define __SERIAL_RF_CMD_H__

#include <SimpleCLI.h>

void createRfCommands(SimpleCLI *cli);

#endif
