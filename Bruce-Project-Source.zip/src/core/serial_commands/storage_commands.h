#ifndef __SERIAL_STORAGE_CMD_H__
#define __SERIAL_STORAGE_CMD_H__

#include <SimpleCLI.h>

void createStorageCommands(SimpleCLI *cli);

#endif

// "storage" cmd to manage files  https://docs.flipper.net/development/cli/#Xgais
